# Content Forge

Gerador de conteúdo de marketing digital com IA.

## Rodar localmente

```
npm install
npm run dev
```

Crie um arquivo `.env.local` com:

```
GROQ_API_KEY=sua_chave_aqui
```

## Deploy (Vercel)

1. Suba este projeto para um repositório no GitHub.
2. Entre em vercel.com, clique em "Add New Project" e importe o repositório.
3. Em "Environment Variables", adicione `ANTHROPIC_API_KEY` com sua chave.
4. Clique em "Deploy".
